import 'core-js/es/map';
import 'core-js/es/set';

import "./test-01";
import "./test-02";
import "./test-03";